package com.opration.crudexample.controller;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opration.crudexample.entity.Product;
import com.opration.crudexample.service.ProductService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("product")
public class ProductController {
	@Autowired
	private ProductService productservices;
	
	@GetMapping
	public Flux<Product> getAllProduct(){
		return	productservices.getAllProduct();
		}
	
	@PostMapping
	public Mono<Product> createProduct(@RequestBody Product product){
        return Objects.isNull(product.getId()) ?
        		this.productservices.createProduct(product):
        		this.productservices.updateProduct(product);
    }
	@DeleteMapping(value="/{id}")
	public Mono<Void> deleteProduct(@PathVariable(name="id") int id){
		return productservices.deleteProduct(id);
		
	} 
	@GetMapping(value="/{id}")
	public Mono<Product> getProductById(@PathVariable(name="id") int id){
		return productservices.getProductById(id);
	}
	
	
	
	

}
