package com.opration.crudexample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opration.crudexample.entity.Product;
import com.opration.crudexample.repository.ProductRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepository;

	public Flux<Product> getAllProduct() {
		return productRepository.findAll();
	}

	public Mono<Product> createProduct(final Product product) {
		return productRepository.save(product);
	}

	public Mono<Product> updateProduct(final Product product) {
		return productRepository.save(product);
	}

	public Mono<Void> deleteProduct(final int id) {
		return this.productRepository.findById(id).flatMap(this.productRepository::delete);
	}
	public Mono<Product> getProductById(final int id){
		return this.productRepository.findById(id);
	}

}
